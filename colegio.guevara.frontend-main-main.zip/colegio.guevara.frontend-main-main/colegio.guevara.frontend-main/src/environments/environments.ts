export const environment = {
    production: false,
    //apiUrl: 'http://localhost/frontend/public/api',
    apiUrl: 'http://192.168.0.3/frontend/public/api',

    appName: 'Colegio Guevara'
  };
  